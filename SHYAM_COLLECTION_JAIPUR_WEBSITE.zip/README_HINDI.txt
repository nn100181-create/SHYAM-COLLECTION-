SHYAM COLLECTION JAIPUR — वेबसाइट फाइल

1) index.html को Chrome में खोलकर वेबसाइट देखें।
2) WhatsApp ऑर्डर चालू करने के लिए index.html को किसी टेक्स्ट एडिटर में खोलें।
3) यह लाइन खोजें:
   const WHATSAPP_NUMBER = "";
   इसमें अपना WhatsApp नंबर country code सहित केवल अंकों में लिखें, उदाहरण: const WHATSAPP_NUMBER = "919876543210";
4) नमूना कीमतों, तस्वीरों और कपड़ों की जानकारी को अपनी वास्तविक जानकारी से बदलें।
5) मुफ्त में ऑनलाइन प्रकाशित करने के लिए GitHub Pages या Netlify जैसे static hosting विकल्प इस्तेमाल किए जा सकते हैं। अकाउंट/पब्लिशिंग के चरण अलग से करने होंगे।
6) यह कैटलॉग वेबसाइट है, अभी इसमें असली payment gateway, inventory system या checkout backend नहीं है।
